#include<iostream>
using namespace std;

class Address{
	string area;
	string city;
	string pincode;
	public :
	Address():area(""),city(""),pincode(""){}
	Address(string area,string city,string pincode):area(area),city(city),pincode(pincode){}
	void Display(){
	cout<<"Area : "<<area<<endl;
	cout<<"City : "<<city<<endl;
	cout<<"Pincode : "<<pincode<<endl;
	}
};

class Student{
	int rollNo;
	string name;
	Address CurrentAddress;
	Address PermenantAddress;
	public:
	Student(int rollNo,string name,Address CurrentAddress,Address PermenantAddress){
		this->rollNo=rollNo;
		this->name=name;
		this->CurrentAddress=CurrentAddress;
		this->PermenantAddress=PermenantAddress;
	}
	Student(int rollNo,string name,string a1,string c1,string p1,string a2,string c2,string p2):
	PermenantAddress(a2,c2,p2)
	{
                this->rollNo=rollNo;
                this->name=name;
		CurrentAddress=(a1,c1,p1);
        }

	Student():rollNo(0),name(""){}
	void Display(){
	cout<<"\nRollNo : "<<rollNo<<endl;
	cout<<"Name : "<<name<<endl;
	cout<<"\nCurrent Address : "<<endl;
	CurrentAddress.Display();
	cout<<"\nPermenant Address : "<<endl;
        PermenantAddress.Display();
	}
};

int main(){
	Address a("Model Colony","pune","440012");
	Address b("Juhu","Mumbai","440013");
//	Student s(11,"sumer",a,b);
	Student s(11,"sumer","Model Colony","pune","440012","Juhu","Mumbai","440013");
	s.Display();
	return 0;
}
