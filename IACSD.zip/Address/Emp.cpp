#include <iostream> 
#include <string> 
#include <vector> 
using namespace std;

class Emp{
	int eid;
	string name;
	string address;
	double salary;

	public:

	void Add(){
	cout<<"Enter Eid: ";
	cin>>eid;
	cout<<"Enter Name: ";
	cin>>name;
	cout<<"Enter Address : ";
	cin>>address;
	cout<<"Enter Salary : ";
	cin>>salary;
	}

	void Display(){
	 cout<<"\nDisplaying vector"<<endl;
	 cout<<"EID : "<<eid<<endl;
	 cout<<"Name : "<<name<<endl;
	 cout<<"Address : "<<address<<endl;
	 cout<<"Salary : "<<salary<<endl;
	}

	int Search(vector <Emp>e,int eid,int n){
	int ind;
	for(int i=0;i<n;i++){
	if(eid==e[i].eid){
		cout<<"found: "<<i+1<<endl;
		ind=i;
	}
	}
	return ind;
	}

	void modify(vector <Emp>& e,int index){
		
		e[index].eid=123;
		e[index].name="om";
		e[index].address="pune";
		e[index].salary=150000;
		cout<<"Modified..."<<endl;
	}
};

int main(){
	Emp e;
	vector<Emp> emp;
	int n;
	cout<<"Enter Number of Employees : ";
	cin>>n;
	for(int i=0;i<n;i++){
	e.Add();
	emp.push_back(e);
	}
	for(int i=0;i<n;i++){
        emp[i].Display();
	}
	int key;
	cout<<"Enter key to Search : ";
	cin>>key;
	int ind=e.Search(emp,key,n);
	cout<<ind;
	//emp.erase(emp.begin()+ind);
	//emp.erase(ind);
	e.modify(emp,ind);
	//cout<<emp[ind]<<endl;
	for(int i=0;i<emp.size();i++){
        emp[i].Display();
        }
	return 0;
}
